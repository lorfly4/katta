// middlewares/setLayoutByRole.js
module.exports = (req, res, next) => {
  const role = req.session.user?.role;

  switch (role) {
    case 'admin':
      req.app.set('layout', 'layouts/layout-admin');
      break;
    case 'sales':
      req.app.set('layout', 'layouts/layout-sales');
      break;
    case 'finance':
      req.app.set('layout', 'layouts/layout-finance');
      break;
    case 'inventory':
      req.app.set('layout', 'layouts/layout-inventory');
      break;
    default:
      req.app.set('layout', 'layouts/template');
  }

  next();
};
